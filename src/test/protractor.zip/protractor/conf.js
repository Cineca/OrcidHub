
exports.config = {
  framework: 'jasmine2',
  seleniumAddress: 'http://localhost:4444/wd/hub',
  specs: ['spec.js'],
  multiCapabilities: [{
//    browserName: 'firefox'
//  }, {
    browserName: 'chrome'
//  },{
//	browserName: 'phantomjs',
//	'phantomjs.binary.path': require('phantomjs').path,
//    'phantomjs.ghostdriver.cli.args': ['--loglevel=DEBUG']
  }],
  rootElement: '[ng-app]',
  
  onPrepare: function() {
	
	  
	    browser.driver.get('http://ubudget-unibo-dev2.sviluppo.u-gov.it');
	    //browser.pause();
	    //console.log(browser.driver.getPageSource());

	    
	    browser.driver.findElement(by.xpath("//input[@name='j_username']")).sendKeys('ADMIN_TESTUSER');
	    browser.driver.findElement(by.xpath("//input[@name='j_password']")).sendKeys('test');
	    browser.driver.findElement(by.xpath("//input[@value='Login']")).click();

	    // Login takes some time, so wait until it's done.
	    // For the test app's login, we know it's done when it redirects to
	    // index.html.
	    //browser.driver.sleep(10000);
	    browser.waitForAngular();
//	    
//	    browser.driver.wait(function() {
//	      return browser.driver.getCurrentUrl().then(function(url) {
//	        return /ubudgetWebApp/.test(url);
//	      });
//	    });
	  },
}